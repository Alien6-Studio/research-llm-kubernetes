"""Launch the server-local guard, then the registered campaign after readiness."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('stage', choices=('guard', 'campaign'))
args = parser.parse_args()
cache = Path.home() / '.cache/alien6-fra6s004-bootstrap'
source = cache / 'source'
guard = cache / 'host-guard-active.json'
if os.uname().nodename.split('.')[0] != 'fra6s004' or os.getuid() != 1000:
    raise SystemExit('Unexpected designated host or operator')
expected = {
    'infra/run-dell-cpu-campaign.py': 'c49bdf466ff812c868868fef4d3b8bce7e8fa9726b1fd2bb9b30639fec334f81',
    'scripts/observe_study_host.py': '75eb4e3c6b5673613e32d4e1457f99cba5900ed4bff010bf3c19e6d64e4a94d9',
    'scripts/freeze_cpu_campaign.py': 'a800f6588b60d5af1c4d84c4280b780368476b2da0f65444f76836848c678a21',
    'v2/cpu_campaigns.py': '59ac024df764fa7d21dd8ff97d4a0ec02775016e5167a09931cd8477db39c6cb',
}
for name, digest in expected.items():
    if hashlib.sha256((source / name).read_bytes()).hexdigest() != digest:
        raise SystemExit('Campaign method changed: ' + name)
if args.stage == 'guard':
    if guard.exists():
        raise SystemExit('A guard checkpoint exists; inspect rather than overwrite')
    unit = 'alien6-fra6s004-cpu-guard'
    command = ['/usr/bin/python3', str(source / 'scripts/observe_study_host.py'), '--out', str(guard), '--min-available-gib', '16', '--max-duration-seconds', '21600']
else:
    if (cache / 'campaign-state').exists():
        raise SystemExit('Campaign state exists; do not relaunch or overwrite trials')
    state = json.loads(guard.read_text())
    if state.get('status') != 'running' or state.get('guard_action') is not None or time.monotonic() - state['samples'][-1]['monotonic'] > 20:
        raise SystemExit('The fresh host guard is not running')
    ready = json.loads((cache / 'readiness.json').read_text())
    if ready.get('ready') is not True or ready.get('generation_requests') != 0 or not ready.get('observer_sampling'):
        raise SystemExit('Non-generative readiness and native process sample must pass first')
    unit = 'alien6-fra6s004-cpu-campaign'
    command = ['/usr/bin/python3', str(source / 'infra/run-dell-cpu-campaign.py'), '--state-dir', str(cache / 'campaign-state'), '--guard-status', str(guard), '--source-id', 'sha256:c811876fbf14c2af54a18f600044368dd0a92561497e0bbdf8d02c2a6bd86c3b', '--git-base', 'db31fdad5e022ae165c1661c41632c1c9a761b84', '--cohort-prefix', 'v2-ollama-fra6s004-cpu', '--image', 'alien6-capacity:fra6s004-cpu-c811876f', '--max-duration-seconds', '21600']
launch = ['sudo', '-n', 'systemd-run', '--quiet', '--no-block', '--unit=' + unit, '--uid=' + str(os.getuid()), '--property=Type=simple', '--property=Restart=no', '--property=KillMode=control-group', '--property=StandardOutput=append:' + str(cache / (unit + '.log')), '--property=StandardError=inherit', '--setenv=PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin', '--setenv=PYTHONDONTWRITEBYTECODE=1', '--working-directory=' + str(source), '--', *command]
subprocess.run(launch, check=True)
print(json.dumps({'launched': unit, 'stage': args.stage, 'independent_of_ssh': True}))
