#!/usr/bin/env python3
"""Supervise the complete registered CPU campaign locally on the Dell host."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.observe_study_host import atomic_checkpoint

CLIENT = "a6-capacity-v2"
INFERENCE = "a6-ollama-study"
PREFIX = "v2-ollama-dell-cpu"
PLAN = "protocol/ollama-dell-cpu-plan.json"
ENVIRONMENT = {
    "PYTHONDONTWRITEBYTECODE": "1",
    "STUDY_OLLAMA_URL": "http://172.16.0.244:11437",
    "STUDY_OLLAMA_BRIDGE_URL": "http://172.16.0.244:11437",
    "STUDY_INFERENCE_ORIGIN": "http://172.16.0.244:11437",
    "STUDY_INFERENCE_MONITOR": "http://172.16.0.244:11436",
}
METHODS = ("infra/run-dell-cpu-campaign.py", "scripts/freeze_cpu_campaign.py", "scripts/observe_study_host.py")
SERVICES = ("alien6-ollama-proxy.service", "alien6-ollama-monitor.service", "alien6-ollama.service")


def utc_now():
    return datetime.now(timezone.utc).isoformat()


class GateFailure(RuntimeError):
    pass


def phase_commands(image):
    pilot = f"runs/{PREFIX}-pilot/pilot.json"
    freeze = ["python3", "scripts/freeze_cpu_campaign.py", "--pilot", pilot, "--out", PLAN]
    for method in METHODS:
        freeze.extend(["--method-file", method])
    return [
        ("pilot", ["python3", "-m", "v2.model", "pilot", "--out", pilot]),
        ("freeze", freeze),
        ("network", ["python3", "-m", "v2.network_probe", "--plan", PLAN, "--url",
                     ENVIRONMENT["STUDY_INFERENCE_ORIGIN"] + "/transport-control", "--out", f"runs/{PREFIX}-network/control.json"]),
        ("qualification", ["python3", "-m", "v2.model", "block", "--plan", PLAN, "--block", "model-qualification", "--image", image, "--out", f"runs/{PREFIX}-qualification"]),
        ("warmup", ["python3", "-m", "v2.model", "warmup", "--out", f"runs/{PREFIX}-warmup/warmup.json"]),
        ("real-model", ["python3", "-m", "v2.model", "block", "--plan", PLAN, "--block", "real-model", "--image", image, "--out", f"runs/{PREFIX}-real-model"]),
    ]


def validate_guard(data, now, boot_id):
    metadata = data.get("metadata", {})
    samples = data.get("samples", [])
    if (data.get("status") != "running" or data.get("complete") is not False
            or data.get("guard_action") is not None or not samples
            or metadata.get("instance") != INFERENCE or metadata.get("boot_id") != boot_id
            or metadata.get("memory_floor_bytes", 0) < 8 * 1024 ** 3):
        raise GateFailure("The outer-host memory guard is not active and qualified for this instance")
    age = now - samples[-1]["monotonic"]
    if age < 0 or age > max(20, 4 * metadata["interval_seconds"]):
        raise GateFailure("The outer-host memory guard checkpoint is stale")


def lxd_command(instance, root, command):
    if instance not in (CLIENT, INFERENCE):
        raise ValueError("Unexpected study instance")
    result = ["lxc", "exec", "local:" + instance, "--cwd", root]
    for key, value in ENVIRONMENT.items():
        result.extend(["--env", key + "=" + value])
    return result + ["--", *command]


def systemd_state(command):
    fields = ("LoadState", "ActiveState", "SubState", "Result", "ExecMainStatus", "ExecMainStartTimestampMonotonic")
    completed = subprocess.run(command + ["--property=" + ",".join(fields)], capture_output=True, text=True, timeout=30)
    if completed.returncode:
        raise GateFailure("Cannot inspect the persistent phase unit: " + completed.stderr.strip())
    state = dict(line.split("=", 1) for line in completed.stdout.splitlines() if "=" in line)
    if state.get("LoadState") != "loaded":
        raise GateFailure("Persistent unit is not loaded")
    return state


def phase_finished(state):
    retained = state.get("ActiveState") == "active" and state.get("SubState") == "exited"
    if retained:
        if (state.get("Result") != "success" or state.get("ExecMainStatus") != "0"
                or int(state.get("ExecMainStartTimestampMonotonic", "0")) <= 0):
            raise GateFailure("Retained phase did not finish successfully")
        return True
    if state.get("ActiveState") in ("active", "activating", "deactivating", "reloading"):
        return False
    if (state.get("ActiveState") != "inactive" or state.get("Result") != "success"
            or state.get("ExecMainStatus") != "0" or int(state.get("ExecMainStartTimestampMonotonic", "0")) <= 0):
        raise GateFailure("Persistent phase failed: " + json.dumps(state, sort_keys=True))
    return True


SOURCE_CHECK = """
import hashlib,json,os,sys
from pathlib import Path
root=Path(sys.argv[1]); os.chdir(root); sys.path.insert(0,str(root))
from v2.identity import capture,verify_worktree
snapshot=capture(root); verify_worktree(root,snapshot.source_id)
if snapshot.source_id != sys.argv[2] or snapshot.git_base != sys.argv[3]:
    raise RuntimeError('Registered source or Git base differs from the approved campaign')
methods={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sys.argv[4:]}
print(json.dumps({**snapshot.metadata(),'methods':methods}))
"""

PREFLIGHT = """
import hashlib,json,sys,urllib.request
from pathlib import Path
from v2.service import code_hash
root=Path.cwd()
targets=[root/'protocol/ollama-dell-cpu-plan.json',root/'protocol/ollama-dell-cpu',root/'archives/v2-ollama-dell-cpu-pilot']
targets += [root/'runs'/('v2-ollama-dell-cpu-'+suffix) for suffix in ('pilot','network','qualification','warmup','real-model')]
if any(path.exists() for path in targets): raise RuntimeError('Campaign outputs already exist; do not retry or overwrite')
with urllib.request.urlopen('http://127.0.0.1:18082/stats',timeout=5) as response: state=json.load(response)
if state.get('source_id') != sys.argv[1] or state.get('code_sha256') != code_hash() or state.get('model_controller_sha256') != hashlib.sha256((root/'v2/model_service.py').read_bytes()).hexdigest():
    raise RuntimeError('Persistent controller forward does not expose the approved instrument')
(root/'study-logs').mkdir(exist_ok=True)
print(json.dumps({'fresh_outputs':True,'controller_source_id':state['source_id']}))
"""

CHECK_PHASE = """
import json,sys
from pathlib import Path
phase,prefix=sys.argv[1:]
root=Path.cwd()
if phase=='freeze':
    from scripts.freeze_cpu_campaign import check_campaign
    result=check_campaign(Path('protocol/ollama-dell-cpu-plan.json'))
elif phase=='pilot':
    from v2.model import validate_pilot
    from v2.verify import verify_cpu_metadata
    data=json.loads((root/'runs'/f'{prefix}-pilot/pilot.json').read_text())
    validate_pilot(data); verify_cpu_metadata(data['metadata']); result={'valid':True}
elif phase=='network':
    data=json.loads((root/'runs'/f'{prefix}-network/control.json').read_text())
    if data.get('qualified') is not True or len(data.get('trials',[])) != 3 or not all(row.get('passed') is True for row in data['trials']):
        raise RuntimeError('All three transport controls must pass')
    result={'qualified':True,'trials':3}
elif phase=='warmup':
    data=json.loads((root/'runs'/f'{prefix}-warmup/warmup.json').read_text())
    if data.get('valid') is not True or len(data.get('observations',[])) != 4 or not all(row.get('correct') is True for row in data['observations']):
        raise RuntimeError('All four warmup responses must pass')
    result={'valid':True,'responses':4}
else:
    expected=12 if phase=='qualification' else 45
    data=json.loads((root/'runs'/f'{prefix}-{phase}/block.json').read_text())
    if data.get('complete') is not True or data.get('qualified') is not True or data.get('trials') != expected or data.get('invalid') != []:
        raise RuntimeError('The complete registered comparison did not qualify')
    result={'complete':True,'qualified':True,'trials':expected}
print(json.dumps(result))
"""

PARTIAL_BLOCK = """
import json,sys
from datetime import datetime,timezone
from pathlib import Path
path=Path('runs')/('v2-ollama-dell-cpu-'+sys.argv[1]); target=path/'block.json'
if path.is_dir() and not target.exists():
    rows=[]
    for item in sorted(path.glob('*.json')):
        data=json.loads(item.read_text())
        if 'configuration' in data and 'result' in data: rows.append(data)
    state={'complete':False,'qualified':False,'trials':len(rows),'invalid':[row['configuration']['trial_id'] for row in rows if row.get('valid') is not True],
           'reason':'Persistent supervisor stopped before block completion; retain all saved trials without a passing-subset inference.',
           'supervisor_finished_utc':datetime.now(timezone.utc).isoformat()}
    with target.open('x') as stream: json.dump(state,stream,indent=2); stream.write('\\n')
"""


class Supervisor:
    def __init__(self, args):
        self.args = args
        self.deadline = time.monotonic() + args.max_duration_seconds
        self.boot_id = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        self.interrupted = False
        self.active_unit = None
        self.active_phase = None
        args.state_dir.mkdir(parents=True, exist_ok=False)
        self.checkpoint = args.state_dir / "status.json"
        self.state = {"status": "starting", "complete": False, "started_utc": utc_now(),
                      "source_id": args.source_id, "git_base": args.git_base, "image": args.image,
                      "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      "scope": "Server-local LXD supervision; no SSH, workstation process, publication or automatic retry.",
                      "guard_checkpoint": str(args.guard_status), "phases": []}
        self.save()

    def save(self):
        self.state["updated_utc"] = utc_now()
        atomic_checkpoint(self.checkpoint, self.state)

    def guard(self):
        if self.interrupted or time.monotonic() >= self.deadline:
            raise GateFailure("Supervisor signal or duration limit reached")
        validate_guard(json.loads(self.args.guard_status.read_text()), time.monotonic(), self.boot_id)

    def capture(self, command):
        completed = subprocess.run(command, capture_output=True, text=True, timeout=60)
        if completed.returncode:
            raise GateFailure(completed.stderr.strip() or completed.stdout.strip() or "Local command failed")
        return completed.stdout

    def vm(self, command):
        return lxd_command(CLIENT, self.args.client_root, command)

    def check_sources(self):
        expected_methods = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in METHODS}
        results = {}
        for instance, root, methods in ((CLIENT, self.args.client_root, METHODS), (INFERENCE, self.args.inference_root, ())):
            result = json.loads(self.capture(lxd_command(instance, root, ["python3", "-c", SOURCE_CHECK, root, self.args.source_id, self.args.git_base, *methods])))
            if methods and result["methods"] != expected_methods:
                raise GateFailure("VM campaign method sources differ from this supervisor")
            results[instance] = result
        self.state["source_verification"] = results
        self.save()

    def wait_staging(self):
        self.state["status"] = "waiting_for_staging"
        self.save()
        for unit in self.args.stage_unit:
            while True:
                self.guard()
                status = systemd_state(["systemctl", "show", unit])
                self.state["staging"] = {"unit": unit, "state": status}
                self.save()
                if phase_finished(status): break
                time.sleep(5)

    def run_phase(self, phase, command):
        self.guard()
        self.check_sources()
        unit = PREFIX + "-" + phase + ".service"
        vm_log = self.args.client_root + "/study-logs/" + PREFIX + "-" + phase + ".log"
        fresh = "from pathlib import Path; import sys; p=Path(sys.argv[1]); p.open('x').close()"
        self.capture(self.vm(["python3", "-c", fresh, vm_log]))
        record = {"phase": phase, "status": "starting", "started_utc": utc_now(), "unit": unit,
                  "command": command, "vm_log": vm_log}
        self.state["phases"].append(record)
        self.state["status"] = phase
        self.active_unit, self.active_phase = unit, phase
        self.save()
        launch = ["systemd-run", "--quiet", "--no-block", "--unit=" + unit,
                  "--property=Type=oneshot", "--property=RemainAfterExit=yes", "--property=StandardOutput=append:" + vm_log,
                  "--property=StandardError=inherit", "--working-directory=" + self.args.client_root]
        launch.extend("--setenv=" + key + "=" + value for key, value in ENVIRONMENT.items())
        self.capture(self.vm(launch + ["--", *command]))
        try:
            while True:
                self.guard()
                status = systemd_state(self.vm(["systemctl", "show", unit]))
                record["unit_state"] = status
                self.save()
                if phase_finished(status): break
                time.sleep(5)
            record["gate"] = json.loads(self.capture(self.vm(["python3", "-c", CHECK_PHASE, phase, PREFIX])))
            record["status"] = "passed"
            self.active_unit = None
        except Exception as error:
            record["status"] = "failed"
            record["error"] = {"type": type(error).__name__, "detail": str(error)}
            raise
        finally:
            record["finished_utc"] = utc_now()
            try:
                output = self.capture(self.vm(["cat", vm_log]))
                (self.args.state_dir / (phase + ".log")).write_text(output)
            except Exception as error:
                record["log_copy_error"] = str(error)
            self.save()

    def cleanup(self):
        results = []
        if self.active_unit:
            command = self.vm(["systemctl", "stop", self.active_unit])
            try:
                completed = subprocess.run(command, capture_output=True, text=True, timeout=60)
                results.append({"target": self.active_unit, "returncode": completed.returncode, "stderr": completed.stderr})
            except Exception as error:
                results.append({"target": self.active_unit, "stop_error": str(error)})
        if self.active_phase in ("qualification", "real-model"):
            try: self.capture(self.vm(["python3", "-c", PARTIAL_BLOCK, self.active_phase]))
            except Exception as error: results.append({"partial_block_error": str(error)})
        command = lxd_command(INFERENCE, self.args.inference_root, ["systemctl", "stop", *SERVICES])
        try:
            completed = subprocess.run(command, capture_output=True, text=True, timeout=90)
            results.append({"target": INFERENCE, "services": SERVICES, "returncode": completed.returncode, "stderr": completed.stderr})
        except Exception as error: results.append({"cleanup_error": str(error)})
        self.state["cleanup"] = results

    def run(self):
        signal.signal(signal.SIGTERM, lambda *_: setattr(self, "interrupted", True))
        signal.signal(signal.SIGINT, lambda *_: setattr(self, "interrupted", True))
        result = 1
        try:
            self.wait_staging()
            self.check_sources()
            self.state["preflight"] = json.loads(self.capture(self.vm(["python3", "-c", PREFLIGHT, self.args.source_id])))
            self.save()
            for phase, command in phase_commands(self.args.image):
                self.run_phase(phase, command)
            self.state["status"] = "campaign_complete"
            self.state["complete"] = True
            result = 0
        except Exception as error:
            self.state["status"] = "stopped_without_retry"
            self.state["error"] = {"type": type(error).__name__, "detail": str(error)}
        finally:
            try: self.cleanup()
            except Exception as error: self.state["cleanup_error"] = str(error)
            self.state["finished_utc"] = utc_now()
            self.save()
        print(json.dumps({"status": self.state["status"], "complete": self.state["complete"], "checkpoint": str(self.checkpoint)}), flush=True)
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state-dir", required=True, type=Path, help="Fresh outer-host checkpoint/log directory")
    parser.add_argument("--guard-status", required=True, type=Path)
    parser.add_argument("--source-id", required=True)
    parser.add_argument("--git-base", required=True)
    parser.add_argument("--image", required=True)
    parser.add_argument("--client-root", default="/opt/alien6-dell-cpu")
    parser.add_argument("--inference-root", default="/opt/alien6-research")
    parser.add_argument("--stage-unit", action="append", default=[], help="Existing outer-host oneshot unit to await; repeat in dependency order")
    parser.add_argument("--max-duration-seconds", type=int, default=21600)
    args = parser.parse_args()
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", args.source_id) or not re.fullmatch(r"(?:[0-9a-f]{40}|[0-9a-f]{64})", args.git_base):
        parser.error("Expected the approved full source identity and Git base")
    if not 0 < args.max_duration_seconds <= 21600:
        parser.error("Supervisor duration must be positive and at most six hours")
    if any(not re.fullmatch(r"[A-Za-z0-9_.@:-]+\.service", unit) for unit in args.stage_unit):
        parser.error("Staging dependencies must be explicit system service names")
    if any(not Path(value).is_absolute() or ".." in Path(value).parts for value in (args.client_root, args.inference_root)):
        parser.error("Instance source roots must be canonical absolute paths")
    if not sys.platform.startswith("linux"):
        parser.error("Run under the outer Linux host's persistent system service")
    return Supervisor(args).run()


if __name__ == "__main__":
    raise SystemExit(main())
