"""Freeze the fresh CPU campaign and its lossless pilot before transport trials."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from v2.identity import capture, verify_worktree
from v2.model import cpu_measurement_seconds, derive_model_plan, validate_pilot
from v2.plan import ROOT
from v2.verify import CPU_COHORT, CPU_INFERENCE_URL, CPU_MAX_MEASUREMENT_SECONDS, CPU_PLAN, CPU_TRACE_DIRECTORY, replay_cpu_plan, validate_cpu_window, verify_cpu_metadata


class CPUPlanningInfeasible(ValueError):
    def __init__(self, record):
        self.record = record
        super().__init__('Pilot-derived CPU window exceeds 120 seconds; pilot and planning decision retained, no comparison trials launched')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def inside(path):
    path = (ROOT / path).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError('Campaign inputs and outputs must stay inside the repository')
    return path


def exclusive_write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    path.chmod(0o444)


def archive_pilot(raw_pilot, pilot_path, archive, frozen):
    encoded = gzip.compress(raw_pilot, compresslevel=9, mtime=0)
    pilot_archive = archive / 'pilot.json.gz'
    exclusive_write(pilot_archive, encoded)
    entry = {'path': str(pilot_archive.relative_to(ROOT)), 'source_relative_path': str(pilot_path.relative_to(ROOT)),
             'sha256': digest(encoded), 'decoded_sha256': digest(raw_pilot), 'decoded_bytes': len(raw_pilot), 'bytes': len(encoded)}
    exclusive_write(archive / 'manifest.json', (json.dumps({'exported_at_utc': frozen,
        'format': 'Lossless gzip copy of the complete native CPU pilot; raw observations are unchanged.',
        'files': [entry]}, indent=2) + '\n').encode())


def freeze_campaign(pilot_path, output_path, method_files=()):
    if not __debug__:
        raise RuntimeError('Scientific plan freezing requires Python assertions')
    pilot_path, output_path = inside(pilot_path), inside(output_path)
    if output_path != (ROOT / CPU_PLAN).resolve():
        raise ValueError('Use the registered flat CPU plan path')
    trace_root = ROOT / CPU_TRACE_DIRECTORY
    archive = ROOT / 'archives' / (CPU_COHORT + '-pilot')
    if output_path.exists() or trace_root.exists() or archive.exists():
        raise FileExistsError('Refusing to overwrite an existing CPU plan, trace set or pilot archive')
    snapshot = capture(ROOT)
    verify_worktree(ROOT, snapshot.source_id)
    raw_pilot = pilot_path.read_bytes()
    pilot = json.loads(raw_pilot)
    validate_pilot(pilot)
    verify_cpu_metadata(pilot['metadata'])
    if pilot.get('source_id') != snapshot.source_id or any(pilot.get(field) != snapshot.git_base for field in ('git_base', 'source_commit')):
        raise ValueError('Fresh CPU pilot differs from the registered collection source')
    loaded = pilot['loaded_model']['models'][0]
    if isinstance(loaded.get('size_vram'), bool) or loaded.get('size_vram') != 0:
        raise ValueError('Fresh CPU pilot does not confirm CPU-only model placement')
    methods = []
    for value in method_files:
        path = inside(value)
        raw = path.read_bytes()
        relative = str(path.relative_to(ROOT))
        if any(entry['path'] == relative for entry in methods):
            raise ValueError('Duplicate campaign method source')
        methods.append({'path': relative, 'sha256': digest(raw), 'bytes': len(raw)})
    methods.sort(key=lambda entry: entry['path'])
    window = cpu_measurement_seconds(pilot)
    frozen = datetime.now(timezone.utc).isoformat()
    archive_pilot(raw_pilot, pilot_path, archive, frozen)
    try:
        validate_cpu_window(window)
    except ValueError:
        decision = {'utc': frozen, **snapshot.metadata(), 'source_commit': snapshot.git_base,
            'feasible': False, 'reason': 'pilot_derived_window_exceeds_registered_cap',
            'pilot_sha256': digest(raw_pilot), 'required_measurement_seconds': window,
            'maximum_measurement_seconds': CPU_MAX_MEASUREMENT_SECONDS, 'comparison_trials_launched': 0}
        exclusive_write(ROOT / 'runs' / (CPU_COHORT + '-planning') / 'planning.json',
                        (json.dumps(decision, indent=2) + '\n').encode())
        raise CPUPlanningInfeasible(decision)
    plan, traces = derive_model_plan(pilot, digest(raw_pilot), CPU_TRACE_DIRECTORY,
                                     measurement_seconds=window, provider_url=CPU_INFERENCE_URL)
    plan['continuation'] = {'cohort': 'ollama-dell-cpu', **snapshot.metadata(), 'frozen_utc': frozen,
        'pilot_archive': 'archives/' + CPU_COHORT + '-pilot/pilot.json.gz',
        'trace_directory': CPU_TRACE_DIRECTORY, 'transport_control': CPU_INFERENCE_URL + '/transport-control',
        'emission_lag_p95_limit_seconds': .05, 'transport_latency_p95_limit_seconds': .1,
        'maximum_measurement_seconds': CPU_MAX_MEASUREMENT_SECONDS,
        'measurement_window_rule': 'max(20, ceil(ceil(10 / frozen_low_rate) / 5) * 5); fresh pilot only, same window in every condition.',
        'qualification_rule': 'Three passing transport repetitions, all twelve passing model-path controls and four correct warmup answers before all forty-five real-model trials.',
        'resource_scope': 'Shared Dell host; separate CPU affinities do not isolate memory bandwidth, caches or other host services.',
        'resource_envelope': {'cpu_quota_cores_upper_bound': 8, 'memory_max_bytes_upper_bound': 28 * 1024 ** 3,
                              'memory_swap_max_bytes_upper_bound': 0}, 'method_sources': methods}
    for relative, encoded in traces.items():
        exclusive_write(ROOT / relative, encoded)
    exclusive_write(trace_root / 'plan.json', (json.dumps(plan, indent=2) + '\n').encode())
    replay_cpu_plan(plan)
    exclusive_write(output_path, (json.dumps(plan, indent=2) + '\n').encode())
    return {'source_id': snapshot.source_id, 'plan_path': str(output_path.relative_to(ROOT)),
            'plan_sha256': digest(output_path.read_bytes()), 'pilot_sha256': plan['pilot_sha256'],
            'measurement_seconds': window, 'rates': plan['rates'],
            'qualification_trials': len(plan['blocks']['model-qualification']),
            'real_model_trials': len(plan['blocks']['real-model'])}


def check_campaign(output_path):
    if not __debug__:
        raise RuntimeError('Scientific plan verification requires Python assertions')
    output_path = inside(output_path)
    snapshot = capture(ROOT)
    verify_worktree(ROOT, snapshot.source_id)
    plan = json.loads(output_path.read_text())
    if plan['continuation']['source_id'] != snapshot.source_id or plan['continuation']['git_base'] != snapshot.git_base:
        raise ValueError('CPU plan differs from the registered collection source')
    replay_cpu_plan(plan)
    return {'checked': True, 'plan_path': str(output_path.relative_to(ROOT)), 'plan_sha256': digest(output_path.read_bytes())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pilot', type=Path, default=Path('runs/' + CPU_COHORT + '-pilot/pilot.json'))
    parser.add_argument('--out', type=Path, default=Path(CPU_PLAN))
    parser.add_argument('--method-file', type=Path, action='append', default=[], help='Retained supervisor/guard source; repeat as needed')
    parser.add_argument('--check', action='store_true', help='Validate an existing frozen plan without changing files')
    args = parser.parse_args()
    try:
        result = check_campaign(args.out) if args.check else freeze_campaign(args.pilot, args.out, args.method_file)
    except CPUPlanningInfeasible as error:
        print(json.dumps(error.record), flush=True)
        raise SystemExit(2)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
