"""Finish verified server staging and start the registered study without SSH."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import time

CACHE = Path.home() / '.cache/alien6-fra6s004-bootstrap'
SOURCE = CACHE / 'source'
STATUS = CACHE / 'confirmation-auto-start-status.json'
CLIENT = '/opt/alien6-fra6s004-cpu'
INFERENCE = '/opt/alien6-research'
SID = 'sha256:c811876fbf14c2af54a18f600044368dd0a92561497e0bbdf8d02c2a6bd86c3b'
BASE = 'db31fdad5e022ae165c1661c41632c1c9a761b84'
SERVICES = ['alien6-ollama.service', 'alien6-ollama-proxy.service', 'alien6-ollama-monitor.service']
assert os.uname().nodename.split('.')[0] == 'fra6s004' and os.getuid() == 1000
assert not STATUS.exists(), 'Inspect the existing startup checkpoint; do not retry blindly'
methods = runpy.run_path(str(SOURCE / 'infra/run-dell-cpu-campaign.py'))
atomic = methods['atomic_checkpoint']
campaign = methods['get_cpu_campaign']('v2-ollama-fra6s004-cpu-confirmation')
state = {'status': 'waiting_for_staging', 'started_utc': datetime.now(timezone.utc).isoformat(),
         'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'source_id': SID, 'git_base': BASE, 'generation_requests_by_startup': 0,
         'campaign_launched': False, 'scope': 'Server-local preparation only; study results are not inferred.'}
started_services = False

def save():
    state['updated_utc'] = datetime.now(timezone.utc).isoformat()
    atomic(STATUS, state)

def command(args, timeout=60, data=None):
    result = subprocess.run(args, input=data, capture_output=True, text=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError(json.dumps({'command': args[:5], 'returncode': result.returncode,
                                       'stderr': result.stderr[-3000:], 'stdout': result.stdout[-2000:]}))
    return result.stdout

def inside(name, root, args):
    return ['lxc', 'exec', 'local:' + name, '--cwd', root, '--env', 'PYTHONDONTWRITEBYTECODE=1', '--', *args]

def guard():
    data = json.loads((CACHE / 'host-guard-confirmation.json').read_text())
    expected = hashlib.sha256((SOURCE / 'scripts/observe_study_host.py').read_bytes()).hexdigest()
    methods['validate_guard'](data, time.monotonic(), Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                              campaign, 6000, expected)

save()
try:
    deadline = time.monotonic() + 2700
    dependencies = [('a6-capacity-v2', CLIENT, 'alien6-fra6s004-client-bootstrap-2.service'),
                    ('a6-ollama-study', INFERENCE, 'alien6-study-stage-exact.service')]
    while True:
        guard()
        complete = True
        state['staging'] = {}
        for name, root, unit in dependencies:
            observed = methods['systemd_state'](inside(name, root, ['systemctl', 'show', unit]))
            state['staging'][name] = observed
            complete = methods['phase_finished'](observed) and complete
        save()
        if complete:
            break
        if time.monotonic() >= deadline:
            raise RuntimeError('Staging exceeded its bounded 45-minute wait; no study launched')
        time.sleep(10)

    state['status'] = 'checking_staged_source'
    save()
    for name, root in [('a6-capacity-v2', CLIENT), ('a6-ollama-study', INFERENCE)]:
        observed = json.loads(command(inside(name, root, ['python3', '-c', methods['SOURCE_CHECK'], root, SID, BASE])))
        assert observed['source_id'] == SID and observed['git_base'] == BASE
    env_check = """from pathlib import Path
env=dict(line.split('=',1) for line in Path('/etc/alien6-research/ollama.env').read_text().splitlines() if line and not line.startswith('#'))
expected={'OLLAMA_NUM_PARALLEL':'4','OLLAMA_MAX_LOADED_MODELS':'1','OLLAMA_MAX_QUEUE':'256','OLLAMA_CONTEXT_LENGTH':'8192','OLLAMA_KEEP_ALIVE':'30m','OLLAMA_NO_CLOUD':'true'}
for key,value in expected.items():
 if env.get(key,'').strip().strip(chr(34)+chr(39))!=value:raise RuntimeError('Unexpected recorded scheduler setting: '+key)
assert Path('/etc/alien6-research/model-staging.json').is_file()
Path('/etc/alien6-research/ready-to-serve').write_text('Verified staging; readiness must pass before generation.'+chr(10))
"""
    command(inside('a6-ollama-study', INFERENCE, ['python3', '-c', env_check]))
    guard()
    state['status'] = 'starting_private_services'
    save()
    started_services = True
    command(inside('a6-ollama-study', INFERENCE, ['systemctl', 'start', *SERVICES]), timeout=90)
    state['status'] = 'waiting_for_private_listeners'
    save()
    listener_wait = """import time,urllib.request
urls=('http://172.30.64.3:11437/api/version','http://172.30.64.3:11436/metadata')
deadline=time.monotonic()+60
while True:
 try:
  for url in urls:
   with urllib.request.urlopen(url,timeout=2) as response:response.read()
  break
 except Exception:
  if time.monotonic()>=deadline:raise
  time.sleep(1)
"""
    command(inside('a6-capacity-v2', CLIENT, ['python3', '-c', listener_wait]), timeout=75)
    raw = command(inside('a6-capacity-v2', CLIENT, ['python3', 'scripts/check_cpu_readiness.py',
          '--cohort-prefix', 'v2-ollama-fra6s004-cpu-confirmation', '--source-id', SID, '--git-base', BASE, '--sample-observer']), timeout=90)
    ready = json.loads(raw)
    assert ready['ready'] is True and ready['generation_requests'] == 0 and ready['observer_sampling']
    atomic(CACHE / 'confirmation-readiness.json', ready)
    write = "from pathlib import Path; import sys; Path('study-logs').mkdir(parents=True,exist_ok=True); Path('study-logs/native-confirmation-readiness.json').write_text(sys.stdin.read())"
    command(inside('a6-capacity-v2', CLIENT, ['python3', '-c', write]), data=raw)
    state['status'] = 'launching_campaign'
    save()
    command(['/usr/bin/python3', str(CACHE / 'launch-confirmation.py'), 'campaign'])
    state['campaign_launched'] = True
    state['status'] = 'campaign_supervised'
    save()
except Exception as error:
    state['status'] = 'stopped_before_campaign' if not state['campaign_launched'] else 'startup_error_after_launch'
    state['error'] = {'type': type(error).__name__, 'detail': str(error)}
    if started_services and not state['campaign_launched']:
        try:
            command(inside('a6-ollama-study', INFERENCE, ['systemctl', 'stop', *SERVICES]), timeout=90)
        except Exception as cleanup_error:
            state['cleanup_error'] = str(cleanup_error)
    save()
    raise
print(json.dumps({'status': state['status'], 'checkpoint': str(STATUS)}), flush=True)
